pygame-goku-en-python
=====================

Mini juego de lucha 2d.

Mini juego de lucha 2d con dos personajes de la serie manga "Bola de dragón".

Este fué el primer juego que desarrollé con gráficos.   
Creía que lo había perdido, pero lo encontré entre cd's antiguos. Lo subo por si a alguien le sirve para aprender sobre la programación de videojuegos para ordenador.   
Uso el lenguaje python y la librería pygame.

<img src="https://raw.github.com/binary-sequence/pygame-goku-en-python/master/screenshot-goku-en-javascript.jpg" style="border:0;">
